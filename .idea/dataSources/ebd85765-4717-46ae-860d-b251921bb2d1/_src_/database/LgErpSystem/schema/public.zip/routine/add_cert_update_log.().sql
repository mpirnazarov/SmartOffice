create function add_cert_update_log() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  organizations varchar(100);
  id_num int;
  org_name varchar(50);
BEGIN
PERFORM 1 FROM trainings WHERE certificate_id=NEW.id LIMIT 1;
IF FOUND THEN
SELECT organization,
name INTO organizations,org_name
from public.certificate_localizations  where certificate_id=new.id;
update trainings set  mark=new.mark, user_id=new.user_id where certificate_id=NEW.id RETURNING id INTO id_num;
update training_localizations set name=org_name, organization=organizations where training_id=id_num;
return new;
ELSE 
   RAISE NOTICE 'not found record id=%', NEW.id;
END IF;
END;
$$;
